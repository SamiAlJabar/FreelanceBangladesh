<?php
	session_start();
	$_SESSION['categor'] = "Graphics & Design";
	header('Location: Seller List.php');
?>

