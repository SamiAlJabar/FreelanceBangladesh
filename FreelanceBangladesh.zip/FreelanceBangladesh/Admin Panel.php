<?php
	session_start();
?>

<!DOCTYPE html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "freelance_bangladesh";

$admin_email = $_SESSION["user_profile"];  //Retrieving value using Session
if($admin_email == "") {
	header('Location: Sign In.php');
}
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 


$missing = array_fill(0, 2000, "");
$sql = "SELECT id, name, email, password, father_name, mother_name, city, date_of_birth, account_type, user_description, money, rating, job_count, nid, phone FROM users";		
$result = $conn->query($sql);
$count = -1;	
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
			
		$count++;
		$user_id[$count] = $row["id"];
		$user_name[$count] = $row["name"];
		$user_email[$count] = $row["email"];
		$user_password[$count] = $row["password"];
		$user_father_name[$count] = $row["father_name"];
		$user_mother_name[$count] = $row["mother_name"];
		$user_city[$count] = $row["city"];
		$user_date_of_birth[$count] = $row["date_of_birth"];
		$user_account_type[$count] = $row["account_type"];
		$user_user_description[$count] = $row["user_description"];
		$user_money[$count] = $row["money"];
		$user_rating[$count] = $row["rating"];
		$user_job_count[$count] = $row["job_count"];
		$user_nid[$count] = $row["nid"];
		$user_phone[$count] = $row["phone"];
	}
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
	if (isset($_POST['delete'])){
	  $deleteNumber = array_pop(array_keys($_REQUEST['delete']));
	  $sql = "DELETE FROM users, seller, buyer, buyer_request WHERE email = '".$user_email[$deleteNumber]."'";
	  $result = $conn->query($sql);
	  
	  $sql = "DELETE FROM users WHERE email = '".$user_email[$deleteNumber]."'";
	  $result = $conn->query($sql);
	  
	  $sql = "DELETE FROM seller WHERE email = '".$user_email[$deleteNumber]."'";
	  $result = $conn->query($sql);
	  
	  $sql = "DELETE FROM buyer WHERE email = '".$user_email[$deleteNumber]."'";
	  $result = $conn->query($sql);
	  
	  $sql = "DELETE FROM buyer_request WHERE email = '".$user_email[$deleteNumber]."'";
	  $result = $conn->query($sql);
	  
	  $sql = "DELETE FROM user_feedback WHERE seller_email = '".$user_email[$deleteNumber]."' OR reviewer_email = '".$user_email[$deleteNumber]."'";
	  $result = $conn->query($sql);
	  
	  $sql = "DELETE FROM orders WHERE seller_email = '".$user_email[$deleteNumber]."' OR buyer_email = '".$user_email[$deleteNumber]."'";
	  $result = $conn->query($sql);
	  
	  $sql = "DELETE FROM message_box WHERE sender_email = '".$user_email[$deleteNumber]."' OR receiver_email = '".$user_email[$deleteNumber]."'";
	  $result = $conn->query($sql);
	  header('Location: Admin Panel.php');
	  
	} else if (isset($_POST['reply'])) {
		$temp = array_keys($_REQUEST['reply']);
		$replyNumber = array_pop($temp);
		if($_POST['message'][$replyNumber] == "") {
			$missing[$replyNumber] = "PLEASE ENTER SOME TEXT TO REPLY!";
			//header('Location: Admin Panel.php');
		} else {
			date_default_timezone_set("Asia/Dhaka");  
			$sql = "INSERT INTO message_box (SENDER_EMAIL, RECEIVER_EMAIL, DATE_TIME, MESSAGE)
				VALUES ('".$admin_email."', '".$user_email[$replyNumber]."', '".date("Y-m-d h:i:sa")."', '".$_POST['message'][$replyNumber]."');";
			$result = $conn->query($sql);
			$missing[$replyNumber] = "MESSAGE SENT SUCCESSFULLY!";
			//header('Location: Admin Panel.php');
		}
	}
}
	
$conn->close();
// Functions


?>	


<html lang="en-US">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>FB / Admin Panel</title>
		
		<link rel="stylesheet" type="text/css" href="home_design.css">
	</head>
	
	
	<body>
	
		<ul id="unordered_bar" style="height:42px">
			<li style="margin-left:100px"><img id="image_logo" src="images/logo.png" alt="LOGO" width="120" /> </li>
			<!--<li style="color:white; margin-left:30px">
				<input id="search" type="text" placeholder="Find People" size="50">
				<button class="button" style="margin-left:5px" onclick="search_people()">GO</button>
			</li>-->
			<!--<li style="color:white; margin-left:420px"> <a class="a1" href="Message.php">MESSAGE</a> </li>
			--><li style="color: white; margin-left:1052px"> <a class="a1" href="Logout.php">LOG OUT</a> </li>
		</ul>
		
		<div id="container">
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="background-color:#292929; width:1370px; margin-left:-450px; margin-top: -80px;">
					<?php
					
					for($i=0; $i<=$count; $i++) {
						?>
						<p style="font-size:15px; color:#4d69f6; "><?php echo "ID - ".$user_id[$i]; ?></p>
						<p style="font-size:15px; color:#4d69f6; "><?php echo "Name - ".$user_name[$i]; ?></p>
						<p style="font-size:15px; color:#4d69f6; "><?php echo "Email - ".$user_email[$i]; ?></p>
						<p style="font-size:15px; color:#4d69f6; "><?php echo "Password - ".$user_password[$i]; ?></p>
						<p style="font-size:15px; color:#4d69f6; "><?php echo "Father's Name - ".$user_father_name[$i]; ?></p>
						<p style="font-size:15px; color:#4d69f6; "><?php echo "Mother's Name - ".$user_mother_name[$i]; ?></p>
						<p style="font-size:15px; color:#4d69f6; "><?php echo "Location - ".$user_city[$i]; ?></p>
						<p style="font-size:15px; color:#4d69f6; "><?php echo "Date of Birth - ".$user_date_of_birth[$i]; ?></p>
						<p style="font-size:15px; color:white; "><?php echo "Account Type - ".$user_account_type[$i]; ?></p>
						<p style="font-size:15px; font-style:italic; color:#4d69f6; "><?php echo "User Description - ".$user_user_description[$i]; ?></p>
						<p style="font-size:15px; color:#4d69f6; "><?php echo "NID - ".$user_nid[$i]; ?></p>
						<p style="font-size:15px; color:#4d69f6;"><?php echo "Phone - " .$user_phone[$i]; ?></p>
						<input class="button" name="reply[<?php echo $i; ?>]" type="submit" value="SEND MESSAGE" style="padding:0px; font-size: 12px; background-color: #4d69f6; width:120px; height:25px;">
						<input class="button" name="delete[<?php echo $i; ?>]" type="submit" value="DELETE USER" style="padding:0px; font-size: 12px; background-color: #4d69f6; width:120px; height:25px;"> <br/>
						<textarea class="user_edit" maxlength="2000" name="message[<?php echo $i; ?>]" type="textarea" placeholder="Enter your reply message here ..." style="font-size:12px; margin-top: 5px; background-color: white; width:1350px; height:60px;"></textarea>
						<span style="color:red; font-size:12px; font-style:italic"><?php echo $missing[$i]; ?></span><br/><br/>
						<p style="font-size:15px; color:#34fb92;">----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</p><br/>
						<?php
					} 
					
					?>
			</form>
		</div>
		
	</body>

</html>