<?php
	session_start();
?>

<!DOCTYPE html>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "freelance_bangladesh";


$user_email = $_SESSION["user_profile"];  //Retrieving value using Session
if($user_email == "") {
	header('Location: Sign In.php');
}


if($_SERVER["REQUEST_METHOD"] == "POST") {	

	$user_name = $_POST["name"];
	$user_user_description = $_POST["description"];
	$user_category = $_POST["category"];
	$user_job_title = $_POST["job_title"];
	$user_city = $_POST["locatio"];

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	$sql = "UPDATE users SET name='".$user_name."', user_description='".$user_user_description."', city='".$user_city."' WHERE email='".$user_email."';";
	$sql .= "UPDATE seller SET category='".$user_category."', job_title='".$user_job_title."' WHERE email='".$user_email."'";

	if ($conn->multi_query($sql) === TRUE) {
		header('Location: Profile.php');
	} else {
		echo "Error updating record: " . $conn->error;
	}

	$conn->close();	
} else {
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 


	$sql = "SELECT name, email, city, account_type, user_description, money, rating FROM users";		
	$result = $conn->query($sql);
			
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
				
			if($row["email"] == $user_email) {
				$user_name = $row["name"];
				$user_city = $row["city"];
				$user_account_type = $row["account_type"];
				$user_user_description = $row["user_description"];
				$user_money = $row["money"];
				$user_rating = $row["rating"];
				break;
			}
		}
	}

	if($user_account_type == "seller") {
		$sql = "SELECT email, category, job_title FROM seller";		
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
					
				if($row["email"] == $user_email) {
					$user_category = $row["category"];
					$user_job_title = $row["job_title"];
					break;
				}
			}
		}
	} else {
		$sql = "SELECT email FROM buyer";		
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
					
				if($row["email"] == $user_email) {
					break;
				}
			}
		}
	}

	$conn->close();
}


?>	


<html lang="en-US">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>FB / Edit Profile</title>
		
		<link rel="stylesheet" type="text/css" href="home_design.css">
	</head>
	
	
	<body>
	
		<ul id="unordered_bar">
			<li style="margin-left:100px"><img id="image_logo" src="images/logo.png" alt="LOGO" width="120" /> </li>
			<!--<li style="color:white; margin-left:30px">
				<input id="search" type="text" placeholder="Find People" size="50">
				<button class="button" style="margin-left:5px" onclick="search_people()">GO</button>
			</li>-->
			<li style="color:white; margin-left:662px"> <a class="a1" href="Profile.php">HOME</a> </li>
			<li style="color:white; margin-left:30px"> <a class="a1" href="Message.php">MESSAGE</a> </li>
			<li style="color:white; margin-left:30px"> <a class="a1" href="Jobs.php">JOBS</a></li>
			<li style="color:#4d69f6; margin-left:30px"> EDIT PROFILE </li>
			<li style="color: white; margin-left:30px"> <a class="a1" href="Logout.php">LOG OUT</a> </li>
		</ul>
		
		<ul id="unordered_category">
			<li style="color:black; margin-left:109px"> <a href="Seller List 1.php">Graphics & Design</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 2.php">Writing & Translation</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 3.php">Programming & Tech</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 4.php">Advertising & Digital Marketing</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 5.php">Video & Animation</a> </li>
		</ul>
		
		<div id="container">
			<img id="image" src="images/sign_in_wallpaper.jpg" alt="LOGO" width="100%"/>
			<form id="profile_edit_form" name="user_edit_form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
				<input maxlength="13" name="name" class="user_edit" value="<?php echo $user_name; ?>" type="text" placeholder="Name" size="40" style="margin-bottom:13px" required> <br/>
				<textarea maxlength="800" name="description" class="user_edit" type="text" size="40" placeholder="Description" style="margin-bottom:13px; width:435px; height:120px" required><?php echo $user_user_description; ?></textarea> <br/>
				<?php
				if($user_account_type == "seller") { ?>
				<select name="category" class="user_edit" style="background-color: white; margin-bottom:13px; width:455px; height:45px; font-size:19px " required>
					<option name="category" value="">Category...</option>
					<option name="category" value="Graphics & Design">Graphics & Design</option>
					<option name="category" value="Writing & Translation">Writing & Translation</option>
					<option name="category" value="Programming & Tech">Programming & Tech</option>
					<option name="category" value="Advertising & Digital Marketing">Advertising & Digital Marketing</option>
					<option name="category" value="Video & Animation">Video & Animation</option>
				</select> <br/>
				<textarea maxlength="400" name="job_title" class="user_edit" type="text" size="40" placeholder="Job Title" style="margin-bottom:13px; width:435px; height:90px" required><?php echo $user_job_title; ?></textarea> <br/>
				<?php } ?>
				<select name="locatio" class="user_edit" style="background-color: white; margin-bottom:13px; width:455px; height:45px; font-size:19px " required>
					<option name="locatio" value="">Select your location...</option>
					<option name="locatio" value="Barisal">Barisal</option>
					<option name="locatio" value="Chittagong">Chittagong</option>
					<option name="locatio" value="Dhaka">Dhaka</option>
					<option name="locatio" value="Khulna">Khulna</option>
					<option name="locatio" value="Mymensingh">Mymensingh</option>
					<option name="locatio" value="Rajshahi">Rajshahi</option>
					<option name="locatio" value="Rangpur">Rangpur</option>
					<option name="locatio" value="Sylhet">Sylhet</option>
				</select> <br/>	
				<input class="button" type="submit" name="submit" value="DONE" style="background-color: #4d69f6; width:224px; height:45px">
				<input type="button" class="button" onClick="location.href='Profile.php';" value="CANCEL" style="background-color: #4d69f6; width:224px; height:45px">
			</form>
		</div>
		
	</body>

</html>