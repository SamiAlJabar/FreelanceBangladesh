<?php
	session_start();
?>

<!DOCTYPE html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "freelance_bangladesh";

//$user_email = $_SESSION["user_profile"];  //Retrieving value using Session
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 


//$sql = "SELECT name, email, city, account_type, user_description, money, rating FROM users";
$sql = "SELECT u.name, u.email, u.city, u.account_type, u.rating,  u.job_count, s.category, s.job_title FROM `users` AS u INNER JOIN `seller` AS s ON u.email = s.email";		
$result = $conn->query($sql);
$count = -1;	
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
			
		if($row["account_type"] == "seller") {
			if($row["category"] == $_SESSION["categor"]) {
				$count++;
				$user_name[$count] = $row["name"];
				$user_email[$count] = $row["email"];
				$user_city[$count] = $row["city"];
				$user_rating[$count] = $row["rating"];
				$user_job_count[$count] = $row["job_count"];
				$user_category[$count] = $row["category"];
				$user_job_title[$count] = $row["job_title"];
			}
		}
	}
}

/*$sql = "SELECT email, job_count, category, job_title FROM seller";		
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
			
		if($row["email"] == $user_email) {
			$user_job_count = $row["job_count"];
			$user_category = $row["category"];
			$user_job_title = $row["job_title"];
		}
	}
}*/
	
$conn->close();
// Functions
	
function signin($user, $pass, $conn) {
	$sql = "SELECT email, password FROM users";		
	$result = $conn->query($sql);
		
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			
			if($row["email"] == $user && $row["password"] == $pass) {
				$x=1;
				$_SESSION['user_profile'] = $user;
				$_SESSION["value_of_counter"] = 0;
				header('Location: Profile.php');
				break;
			}
			else {
				$x=2;
			}
		}
			
		if($x == 2) {
			return "Wrong username or password!";
		}
	}
}

?>	


<html lang="en-US">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>FB / <?php echo $_SESSION["categor"]; ?></title>
		
		<link rel="stylesheet" type="text/css" href="home_design.css">
	</head>
	
	
	<body>
	
		<ul id="unordered_bar">
			<li style="margin-left:100px"><img id="image_logo" src="images/logo.png" alt="LOGO" width="120" /> </li>
			<!--<li style="color:white; margin-left:30px">
				<input id="search" type="text" placeholder="Find People" size="50">
				<button class="button" style="margin-left:5px" onclick="search_people()">GO</button>
			</li>-->
			<li style="color:white; margin-left:852px"> <a class="a1" href="Profile.php">PROFILE</a> </li>
			<li style="color:white; margin-left:60px"> <a class="a1" href="Registration.php">JOIN</a> </li>
			<li style="color: white; margin-left:60px"> <a class="a1" href="Sign In.php">SIGN IN</a> </li>
		</ul>
		
		<ul id="unordered_category" style="background-color: #e6e6e6">
			<li style="color:black; margin-left:109px"> <a href="Seller List 1.php">Graphics & Design</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 2.php">Writing & Translation</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 3.php">Programming & Tech</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 4.php">Advertising & Digital Marketing</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 5.php">Video & Animation</a> </li>
		</ul>
		
		<div id="container">
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="background-color:#292929; width:1370px; margin-left:-450px; margin-top: -80px;">
					<?php
					
					if($count == -1) {
						?><p style="font-size:24px; color:#4d69f6; "><?php echo "No freelancers under this category"; ?></p><?php
					} else {
						for($i=0; $i<=$count; $i++) {
							?>
							<p style="font-size:24px; color:#4d69f6; "><?php echo $user_name[$i]; ?></p>
							<p style="font-size:15px; color:#34fb92;"><?php echo "Rating / Job Count - " .$user_rating[$i]. " / " .$user_job_count[$i]; ?></p>
							<p style="font-size:15px; color:#34fb92"><?php echo "Location - " .$user_city[$i]; ?></p>
							<p style="color:white; font-size:15px; font-style:italic;"><?php echo $user_job_title[$i]; ?></p> <br/>
							<!--<input class="button" name="hire[<?php echo $i; ?>]" type="submit" value="HIRE" style="padding:0px; font-size: 12px; background-color: #4d69f6; width:80px; height:25px;">
							<textarea class="user_edit" maxlength="2000" name="message[<?php echo $i; ?>]" type="textarea" placeholder="Enter your reply message here ..." style="font-size:12px; margin-top: 5px; background-color: white; width:1350px; height:60px;"><?php echo $missing[$i]; ?></textarea> <br/><br/>
						--><?php
						} 
					} 
					
					?>
			</form>
		</div>
		
	</body>

</html>