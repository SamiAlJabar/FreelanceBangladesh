<!DOCTYPE html>
<?php
$profile = $name = $fname = $mname = $dob = $city = $nid = $phone = $email = $user_password = $user_confirm_password = "";
$error = "";
if($_SERVER["REQUEST_METHOD"] == "POST") {
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "freelance_bangladesh";

	$profile = $_POST["profile"];
	$name = $_POST["name"];
	$fname = $_POST["fname"];
	$mname = $_POST["mname"];
	$dob = $_POST["dob"];
	$city = $_POST["city"];
	$nid = $_POST["nid"];
	$phone = $_POST["phone"];
	$email = $_POST["email"];
	$user_password = $_POST["password"];
	$user_confirm_password = $_POST["confirm_password"];

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	$error = checkEmail($name, $email, $user_password, $fname, $mname, $city, $dob, $profile, $nid, $phone, $conn);
	if($error == "This email id is occupied!") {
		$email = "";
	}
	$conn->close();	
}

// Functions
function checkEmail($name, $email, $user_password, $fname, $mname, $city, $dob, $profile, $nid, $phone, $conn) {
	$sql = "SELECT EMAIL FROM users";
	$result = $conn->query($sql);
	$x=0;
	
	if ($result->num_rows > 0) {
		// output data of each row
		
		while($row = $result->fetch_assoc()) {
		
			if($row["EMAIL"] == $email) {
				$x=1;
				return "This email id is occupied!";
				break;
			} else {
				$x=2;
			}
		}
			
		if($x == 2) {
			saveInfo($name, $email, $user_password, $fname, $mname, $city, $dob, $profile, $nid, $phone, $conn);  //function call
		} else {
			$error = "   Email is occupied!";
		}
	} else {
		saveInfo($name, $email, $user_password, $fname, $mname, $city, $dob, $profile, $nid, $phone, $conn);  //function call
	}
}

function saveInfo($name, $email, $user_password, $fname, $mname, $city, $dob, $profile, $nid, $phone, $conn) {
	
	if($profile == "buyer") {
		$sql = "INSERT INTO users (NAME, EMAIL, PASSWORD, FATHER_NAME, MOTHER_NAME, CITY, 
			DATE_OF_BIRTH, ACCOUNT_TYPE, NID, PHONE)
			VALUES ('".$name."', '".$email."', '".$user_password."', '".$fname."', '".$mname."', '".$city."', '".$dob."'
			, '".$profile."', '".$nid."', '".$phone."');";
		$sql .= "INSERT INTO buyer (EMAIL)
			VALUES ('".$email."')";
			
		if ($conn->multi_query($sql) === TRUE) {
			header('Location: Sign In.php');
		}
		
	} else {
		$sql = "INSERT INTO users (NAME, EMAIL, PASSWORD, FATHER_NAME, MOTHER_NAME, CITY, 
			DATE_OF_BIRTH, ACCOUNT_TYPE, NID, PHONE)
			VALUES ('".$name."', '".$email."', '".$user_password."', '".$fname."', '".$mname."', '".$city."', '".$dob."'
			, '".$profile."', '".$nid."', '".$phone."');";
		$sql .= "INSERT INTO seller (EMAIL)
			VALUES ('".$email."')";
			
		
		if ($conn->multi_query($sql) === TRUE) {
			header('Location: Sign In.php');
		}
	}
		
	
}

?>


<html lang="en-US">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>Freelance Bangladesh / Register</title>
		
		<link rel="stylesheet" type="text/css" href="home_design.css">
	</head>
	
	
	<body>
	
		<ul id="unordered_bar">
			<li style="margin-left:100px"><img id="image_logo" src="images/logo.png" alt="LOGO" width="120" /> </li>
			<!--<li style="color:white; margin-left:30px">
				<input id="search" type="text" placeholder="Find People" size="50">
				<button class="button" style="margin-left:5px" onclick="search_people()">GO</button>
			</li>-->
			<li style="color: #4d69f6; margin-left:987px"> JOIN</li>
			<li style="color: white; margin-left:60px"> <a class="a1" href="Sign In.php">SIGN IN</a> </li>
		</ul>
		
		<ul id="unordered_category">
			<li style="color:black; margin-left:109px"> <a href="Seller List 1.php">Graphics & Design</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 2.php">Writing & Translation</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 3.php">Programming & Tech</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 4.php">Advertising & Digital Marketing</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 5.php">Video & Animation</a> </li>
		</ul>
		
		<div id="container">
			<img id="image" src="images/sign_in_wallpaper.jpg" alt="LOGO" width="100%"/>
			<form name="user_registration_form" id="reg_form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" onsubmit="return validateForm()">
				<input id="user_registration" style="margin-left:49px" type="radio" name="profile" value="buyer" required> Buyer 
				<input id="user_registration" style="margin-left:78px; margin-bottom:8px" type="radio" name="profile" value="seller" required> Seller<br>
				
				<input maxlength="13" id="user_registration" name="name" value="<?php echo $name ?>" type="text" placeholder="Name" size="40" style="margin-bottom:10px" required><br/>
				<input maxlength="30" id="user_registration" name="fname" value="<?php echo $fname ?>" type="text" size="40" placeholder="Father's Name" style="margin-bottom:10px" required> <br/>
				<input maxlength="30" id="user_registration" name="mname" value="<?php echo $mname ?>" type="text" size="40" placeholder="Mother's Name" style="margin-bottom:10px" required> <br/>
				<input maxlength="10" id="user_registration" name="dob" value="<?php echo $dob ?>" pattern="\d{4}/\d{1,2}/\d{1,2}" type="text" size="40" placeholder="Date Of Birth (e.g yyyy/mm/dd)" style="margin-bottom:10px" required> <br/>
				
				<select id="user_registration" name="city" style="background-color: white; margin-bottom:13px; width:368px; height:40px; font-size:11px;" required>
					<option name="city" value="">Select your location...</option>
					<option name="city" value="Barisal">Barisal</option>
					<option name="city" value="Chittagong">Chittagong</option>
					<option name="city" value="Dhaka">Dhaka</option>
					<option name="city" value="Khulna">Khulna</option>
					<option name="city" value="Mymensingh">Mymensingh</option>
					<option name="city" value="Rajshahi">Rajshahi</option>
					<option name="city" value="Rangpur">Rangpur</option>
					<option name="city" value="Sylhet">Sylhet</option>
				</select> <br/>	
				
				<input maxlength="14" id="user_registration" name="nid" value="<?php echo $nid ?>" type="text" size="40" placeholder="National ID" style="margin-bottom:10px" required> <br/>
				<input maxlength="11" id="user_registration" name="phone" value="<?php echo $phone ?>" type="number" placeholder="Phone Number (e.g 01xxxxxxxxx)" style="width:347px ;margin-bottom:10px" required> <br/>
				<input maxlength="40" id="user_registration" name="email" value="<?php echo $email ?>" type="email" size="40" placeholder="Email" style="margin-bottom:10px" required> <br/>
				<input maxlength="20" id="user_registration" name="password" type="password" size="40" placeholder="Password" style="margin-bottom:10px" required> <br/>
				<input maxlength="20" id="user_registration" name="confirm_password" type="password" size="40" placeholder="Confirm Password" required> <br/>
				<span style="margin:44px; color:red" id="conf_pass"> <?php echo $error; ?></span> <br/>
				<input type="submit" class="button" name="submit" value="Sign Up" style="background-color: #4d69f6; width:367px; height:44px;">
			</form>
		</div>
		
		
		<script>
			function validateForm() {
				var pass = document.forms["user_registration_form"]["password"].value;
				var conf_pass = document.forms["user_registration_form"]["confirm_password"].value;
				
				if(conf_pass == "") {
				
				} else if(conf_pass != pass){
					document.getElementById("conf_pass").innerHTML = "Password did not match!";
					document.forms["user_registration_form"]["password"].value = "";
					document.forms["user_registration_form"]["confirm_password"].value = "";
					return false;
				} else {
					return true;
				}
			}
		</script>
	</body>

</html>