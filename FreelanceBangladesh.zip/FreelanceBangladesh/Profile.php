<?php
	session_start();
?>

<!DOCTYPE html>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "freelance_bangladesh";


$user_email = $_SESSION["user_profile"];  //Retrieving value using Session
if($user_email == "") {
	header('Location: Sign In.php');
} else if ($user_email == "Jabar@jj.com") {
	header('Location: Admin Panel.php');
}
$missing = "";
// Createing connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Checking connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT name, email, city, account_type, user_description, money, rating, job_count FROM users";
$result = $conn->query($sql);
		
if ($result->num_rows > 0) {
	// output data of each row
	while($row = $result->fetch_assoc()) {
			
		if($row["email"] == $user_email) {
			
			$user_job_count = $row["job_count"];
			$user_name = $row["name"];
			$user_city = $row["city"];
			$user_account_type = $row["account_type"];
			$user_user_description = $row["user_description"];
			$user_money = $row["money"];
			break;
		}
	}
}

$feeds = -1;
$sql = "SELECT reviewer_email, seller_email, feedback, date_time, rating FROM user_feedback ORDER BY id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	// output data of each row
	while($row = $result->fetch_assoc()) {
			
		if($row["seller_email"] == $user_email) {
			$feeds++;
			$user_rev_email[$feeds] = $row["reviewer_email"];
			$user_feedback[$feeds] = $row["feedback"];
			$user_dateandtime[$feeds] = $row["date_time"];
			$user_rating2[$feeds] = $row["rating"];
		}
	}
}


$sql = "SELECT email, rating FROM users ORDER BY id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	// output data of each row
	while($row = $result->fetch_assoc()) {
		if($row["email"] == $user_email) {
			$user_rating = $row["rating"];
			break;
		}
	}
}
			
if($user_account_type == "seller") {
	$sql = "SELECT email, category, job_title FROM seller";		
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
				
			if($row["email"] == $user_email) {
				$user_category = $row["category"];
				$user_job_title = $row["job_title"];
				break;
			}
		}
		
		if($user_user_description == "" || $user_category == "" || $user_job_title == "") {
			header('Location: Edit Profile.php');
		}

	}
	
	$sql = "SELECT email, category, request FROM buyer_request ORDER BY id DESC";		
	$result = $conn->query($sql);
	$request_counter=-1;
	if ($result->num_rows > 0) {
		// output data of each row
		
		while($row = $result->fetch_assoc()) {
				
			if($row["category"] == $user_category) {
				$request_counter++;
				$user_request[$request_counter] = $row["request"];
				$user_buyer_email[$request_counter] = $row["email"];
			}
		}
		
		if($user_user_description == "" || $user_category == "" || $user_job_title == "") {
			header('Location: Edit Profile.php');
		}
	} 
	
	if($request_counter == -1) {
		$request_counter = 999;
	} 
	
} else {
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
				
			if($row["email"] == $user_email) {
				$user_job_count = $row["job_count"];
				break;
			}
		}
		
		if($user_user_description == "") {
			header('Location: Edit Profile.php');
		}
	}
}


// For the form submission while making a request
if($_SERVER["REQUEST_METHOD"] == "POST" && $user_account_type == "seller") {
	if (isset($_POST['next'])) {
		$_SESSION["value_of_counter"]++;
		if($_SESSION["value_of_counter"] > $request_counter) {
			$_SESSION["value_of_counter"]--;
		}
	} else if (isset($_POST['previous'])){
		$_SESSION["value_of_counter"]--;
		if($_SESSION["value_of_counter"] < 0) {
			$_SESSION["value_of_counter"] = 0;
		}
	} else if (isset($_POST['contact'])){
		if($_POST['message'] == "") {
			$missing = "THIS FIELD CANNOT BE EMPTY.";
		} else if ($request_counter == 999){
			$missing = "You cannot send message to 'NO ONE'";
		} else {
			date_default_timezone_set("Asia/Dhaka");  
			$sql = "INSERT INTO message_box (SENDER_EMAIL, RECEIVER_EMAIL, DATE_TIME, MESSAGE)
				VALUES ('".$user_email."', '".$user_buyer_email[$_SESSION["value_of_counter"]]."', '".date("Y-m-d h:i:sa")."', '".$_POST['message']."');";
			$result = $conn->query($sql);
		}
	}
	
	
} else if($_SERVER["REQUEST_METHOD"] == "POST" && $user_account_type == "buyer") {
	$user_job_category = $_POST["job_category"];
	$user_request = $_POST["jobpost"];
	$temp = 0;
	
	$sql = "SELECT email FROM buyer_request";		
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
				
			if($row["email"] == $user_email) {
				$sql = "DELETE FROM buyer_request WHERE EMAIL = '".$user_email."'";
				$result = $conn->query($sql);
				break;
			}
		}
	}
		
	$sql = "INSERT INTO buyer_request (EMAIL, CATEGORY, REQUEST)
					VALUES ('".$user_email."', '".$user_job_category."', '".$user_request."');";
	$result = $conn->query($sql);
	?><script> alert("Your job request has been posted successfully. If you post a new request, your previous request will be overwritten."); </script> <?php
	
}

$conn->close();

?>	

<html lang="en-US">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>FB / <?php echo $user_name; ?></title>
		
		<link rel="stylesheet" type="text/css" href="home_design.css">
	</head>
	
	
	<body>
	
		<ul id="unordered_bar">
			<li style="margin-left:100px"><img id="image_logo" src="images/logo.png" alt="LOGO" width="120"></li>
			<!--<li style="color:white; margin-left:30px">
				<input id="search" type="text" placeholder="Find People" size="50">
				<button class="button" style="margin-left:5px" onclick="search_people()">GO</button>
			</li>-->
			<li style="color: #4d69f6; margin-left:662px"> HOME </li>
			<li style="color:white; margin-left:30px"> <a class="a1" href="Message.php">MESSAGE</a> </li>
			<li style="color:white; margin-left:30px"> <a class="a1" href="Jobs.php">JOBS</a></li>
			<li style="color:white; margin-left:30px"> <a class="a1" href="Edit Profile.php">EDIT PROFILE</a> </li>
			<li style="color: white; margin-left:30px"> <a class="a1" href="Logout.php">LOG OUT</a> </li>
		</ul>
		
		<ul id="unordered_category">
			<li style="color:black; margin-left:109px"> <a href="Seller List 1.php">Graphics & Design</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 2.php">Writing & Translation</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 3.php">Programming & Tech</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 4.php">Advertising & Digital Marketing</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 5.php">Video & Animation</a> </li>
		</ul>
		
		<div id="container">
		
			<?php if($user_account_type == "seller") { 
				if($user_rating == 0) {
					?> <img class="stars" src="images/0_Star.png" alt="0 Star" width="10%"/> <?php
				} else if($user_rating == 1) {
					?> <img class="stars" src="images/1_Star.png" alt="1 Star" width="10%"/> <?php	
				} else if($user_rating == 2) {
					?> <img class="stars" src="images/2_Star.png" alt="2 Star" width="10%"/> <?php	
				} else if($user_rating == 3) {
					?> <img class="stars" src="images/3_Star.png" alt="3 Star" width="10%"/> <?php	
				} else if($user_rating == 4) {
					?> <img class="stars" src="images/4_Star.png" alt="4 Star" width="10%"/> <?php	
				} else if($user_rating == 5) {
					?> <img class="stars" src="images/5_Star.png" alt="5 Star" width="10%"/> <?php	
				}
			?> <p id="review"> <?php echo "(" .$user_job_count. " reviews)"; ?></p> <?php
			}
			?>
			<img id="image" src="images/sign_in_wallpaper.jpg" alt="Wallpaper" width="100%"/>
			<p id="name_header"> <?php echo $user_name; ?></p>  
			<p style="margin-left:-40px" id="location"> <?php echo "Location: " .$user_city; ?></p> 
			<p id="about"> <?php echo $user_user_description; ?></p>
			
			<!-- Buyer Request / Seller Job Posts-->
			<?php
			if($user_account_type == "buyer") { ?>
				<form style="margin-left: -388px; margin-top: 161px" name="job_request_form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
					<textarea class="user_edit" maxlength="975" name="jobpost" style="padding:10px; font-size:12px; margin-top:10px; margin-bottom: 10px; width:410px; height:160px; background-color:white;
						color:black;" placeholder="Are you looking for freelancer? Type here about what you are looking for ..." required></textarea > <br/>
						
						<select name="job_category" class="user_edit" style="background-color: white; margin-bottom:10px; width:430px; height:45px; font-size:19px " required>
							<option name="category" value="">Category...</option>
							<option name="category" value="Graphics & Design">Graphics & Design</option>
							<option name="category" value="Writing & Translation">Writing & Translation</option>
							<option name="category" value="Programming & Tech">Programming & Tech</option>
							<option name="category" value="Advertising & Digital Marketing">Advertising & Digital Marketing</option>
							<option name="category" value="Video & Animation">Video & Animation</option>
						</select> <br/>
						
					<input class="button" type="submit" name="submit" value="DONE" style="background-color: #4d69f6; width:430px; height:55px;">
				</form> <?php
			} else {
				?>  <p id="location" name="money" style="color:#34fb92; font-size:24px; margin-top:0px; margin-left: 270px;"> <?php echo "Tk. " .$user_money; ?></p>
					<span id="category"> <?php echo $user_category; ?></span>
				    <span id="about" style="margin-top: 281px; color:yellow;" > <?php echo $user_job_title; ?></span>
				    <span style="margin-top:0px; margin-left:520px; width:770px; height:460px"
						id="about"></span> 
						
				<?php if($request_counter == 999) { ?>
					<p id="location" name="req" style="color:white; font-size:16px; margin-top:80px; margin-right: 120px;"> <?php echo "No requests!"; ?></p>
				<?php } else { ?>
					<p id="location" name="req" style="color:white; font-size:16px; margin-top:80px; margin-right: 120px;"> <?php echo $user_request[$_SESSION["value_of_counter"]]; ?></p>	
				<?php } ?>
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="margin-left: 160px; margin-top: 250px; background-color: transparent;" name="request_form_contact">
					<textarea class="user_edit" maxlength="2000" name="message" type="textarea" placeholder="Enter your message here ..." style="font-size:12px; margin-bottom:10px; background-color: white; width:680px; height:80px;"><?php echo $missing; ?></textarea>	
					<input class="button" name="previous" type="submit" value="PREVIOUS" style="background-color: #4d69f6; width:210px; height:45px;">
					<input class="button" name="contact" type="submit" value="SEND" style="margin-left:28px; background-color: #4d69f6; width:210px; height:45px;">
					<input class="button" name="next" type="submit" value="NEXT" style="margin-left:28px; background-color: #4d69f6; width:210px; height:45px;">					
				</form>
			<?php
			
			} ?>
		</div>	
		
		<?php if($user_account_type == "seller") {
		?>
		<form class="feedback" style="background-color:#292929; width:1370px; margin-bottom:100px; margin-left:-450px; margin-top: 650px;">
					<?php
					?><p style="font-size:40px; color:white"><?php echo "Feedbacks / Reviews"; ?></p><?php
					if($feeds == -1) {
						
					} else {
						for($i=0; $i<=$feeds; $i++) {
						?>
							<p style="font-size:20px; color:#4d69f6;"><?php echo $user_rev_email[$i]. " (" .$user_dateandtime[$i]. ")" ?></p>
							<p style="font-size:17px; color:#34fb92;"><?php echo "Rating (out of 5) - ". $user_rating2[$i]. " Star"; ?></p>
							<p style="font-style:italic; color:white; font-size:15px;"><?php echo $user_feedback[$i]; ?></p> <br/>
						<?php
						} 
					} 
					
					?>
		</form>
		<?php } ?>
	</body>
</html>