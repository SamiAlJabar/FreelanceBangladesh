<?php
	session_start();
	$_SESSION['categor'] = "Advertising & Digital Marketing";
	header('Location: Seller List.php');
?>