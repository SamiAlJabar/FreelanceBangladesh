<?php
	session_start();
?>

<!DOCTYPE html>
<?php
$error = $email = "";
if($_SERVER["REQUEST_METHOD"] == "POST") {
	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "freelance_bangladesh";

	$email = $_POST["email"];
	$user_password = $_POST["password"];
	$x = 0;

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 

	$error = signin($email, $user_password, $conn, $x);  //function call
	if($error == "Wrong username or password!") {
		$email = "";
	}
	$conn->close();
}

// Functions
	
function signin($user, $pass, $conn) {
	$sql = "SELECT email, password FROM users";		
	$result = $conn->query($sql);
		
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			
			if($row["email"] == $user && $row["password"] == $pass) {
				$x=1;
				$_SESSION['user_profile'] = $user;
				$_SESSION["value_of_counter"] = 0;
				$_SESSION["error_message"] = "";
				header('Location: Profile.php');
				break;
			}
			else if($user == "Jabar@jj.com" && $pass == "jabar") {
				$_SESSION['user_profile'] = $user;
				header('Location: Admin Panel.php');
			} else {
				$x=2;
			}
		}
			
		if($x == 2) {
			return "Wrong username or password!";
		}
	}
}

?>	


<html lang="en-US">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>FB / Sign In</title>
		
		<link rel="stylesheet" type="text/css" href="home_design.css">
	</head>
	
	
	<body>
		<ul id="unordered_bar">
			<li style="margin-left:100px"><img id="image_logo" src="images/logo.png" alt="LOGO" width="120" /> </li>
			<!--<li style="color:white; margin-left:30px">
				<input id="search" type="text" placeholder="Find People" size="50">
				<button class="button" style="margin-left:5px" onclick="search_people()">GO</button>
			</li>-->
			<li style="color:white; margin-left:987px"> <a class="a1" href="Registration.php">JOIN</a> </li>
			<li style="color: #4d69f6; margin-left:60px"> SIGN IN </li>
		</ul>
		
		<ul id="unordered_category">
			<li style="color:black; margin-left:109px"> <a href="Seller List 1.php">Graphics & Design</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 2.php">Writing & Translation</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 3.php">Programming & Tech</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 4.php">Advertising & Digital Marketing</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 5.php">Video & Animation</a> </li>
		</ul>
		
		<div id="container">
			<img id="image" src="images/sign_in_wallpaper.jpg" alt="LOGO" width="100%"/>
			<form name="user_signin_form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
				<input name="email" id="user_auth" value="<?php echo $email; ?>" type="email" placeholder="Email" size="40" style="margin-bottom:13px" required> <br/>
				<input name="password" id="user_auth" type="password" size="40" placeholder="Password" style="margin-bottom:5px" required> <br/>
				<span style="color:red; margin-left:60px"> <?php echo $error; ?> </span> <br/>
				<input class="button" type="submit" name="submit" value="LOGIN" style="background-color: #4d69f6; width:466px; height:55px; margin-top:5px">
			</form>
		</div>	
		
		<div id="aboutme">
			<button class="button" type="button" onclick="about()">?</button>
		</div>
		
		<script>
		function about() {
		  var xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			  document.getElementById("aboutme").innerHTML =
			  this.responseText;
			}
		  };
		  xhttp.open("GET", "about_me.txt", true);
		  xhttp.send();
		}
		</script>
	</body>
</html>