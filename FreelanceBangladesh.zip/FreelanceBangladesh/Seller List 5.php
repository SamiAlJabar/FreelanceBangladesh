<?php
	session_start();
	$_SESSION['categor'] = "Video & Animation";
	header('Location: Seller List.php');
?>