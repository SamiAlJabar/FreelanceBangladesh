<?php
	session_start();
	$_SESSION['categor'] = "Programming & Tech";
	header('Location: Seller List.php');
?>