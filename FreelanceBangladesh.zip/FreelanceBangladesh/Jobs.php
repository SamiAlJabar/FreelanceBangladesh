<?php
	session_start();
?>

<!DOCTYPE html>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "freelance_bangladesh";


$user_email = $_SESSION["user_profile"];  //Retrieving value using Session
if($user_email == "") {
	header('Location: Sign In.php');
}

$missing = array_fill(0, 2000, "");
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 


$sql = "SELECT name, email, city, account_type, user_description, money, rating FROM users";		
$result = $conn->query($sql);
		
if ($result->num_rows > 0) {
	// output data of each row
	while($row = $result->fetch_assoc()) {
			
		if($row["email"] == $user_email) {
			$user_name = $row["name"];
			$user_city = $row["city"];
			$user_account_type = $row["account_type"];
			$user_user_description = $row["user_description"];
			$user_money = $row["money"];
			$user_rating = $row["rating"];
			break;
		}
	}
}

$sql = "SELECT id, buyer_email, seller_email, date_time, order_statement, cost, first_status, second_status FROM orders ORDER BY id DESC";		
$result = $conn->query($sql);

$order_counter = -1;
if ($result->num_rows > 0) {
	// output data of each row
	if($user_account_type == "seller") {
		while($row = $result->fetch_assoc()) {
			if($row["seller_email"] == $user_email) {
				$order_counter++;
				$user_buyer_email[$order_counter] = $row["buyer_email"];
				$user_id[$order_counter] = $row["id"];
				$user_cost[$order_counter] = $row["cost"];
				$user_date_time[$order_counter] = $row["date_time"];
				$user_order_statement[$order_counter] = $row["order_statement"];
				$user_first_status[$order_counter] = $row["first_status"];
				$user_second_status[$order_counter] = $row["second_status"];
			}
		}
	} else {
		while($row = $result->fetch_assoc()) {
			if($row["buyer_email"] == $user_email) {
				$order_counter++;
				$user_seller_email[$order_counter] = $row["seller_email"];
				$user_id[$order_counter] = $row["id"];
				$user_cost[$order_counter] = $row["cost"];
				$user_date_time[$order_counter] = $row["date_time"];
				$user_order_statement[$order_counter] = $row["order_statement"];
				$user_first_status[$order_counter] = $row["first_status"];
				$user_second_status[$order_counter] = $row["second_status"];
			}
		}
	}
}

$sql = "SELECT id, sender_email, receiver_email, date_time, message FROM message_box ORDER BY id DESC";		
$result = $conn->query($sql);
$message_counter=-1;
if ($result->num_rows > 0) {
	// output data of each row
	while($row = $result->fetch_assoc()) {
		if($row["receiver_email"] == $user_email) {
			$message_counter++;
			$user_receiver_email = $row["receiver_email"];
			$user_id2[$message_counter] = $row["id"];
			$user_sender_email[$message_counter] = $row["sender_email"];
			$user_date_time2[$message_counter] = $row["date_time"];
			$user_message[$message_counter] = $row["message"];
		}
	}
}

$i=0;
// For the form submission while making a request
if($_SERVER["REQUEST_METHOD"] == "POST" && $user_account_type == "buyer") {
	if (isset($_POST['reply'])) {
		$temp = array_keys($_REQUEST['reply']);
		$replyNumber = array_pop($temp);
		if($_POST['message'][$replyNumber] == "") {
			$missing[$replyNumber] = "PLEASE ENTER SOME TEXTS TO REPLY!";
			//header('Location: Jobs.php');
		} else {
			date_default_timezone_set("Asia/Dhaka"); 
			$sql = "INSERT INTO message_box (SENDER_EMAIL, RECEIVER_EMAIL, DATE_TIME, MESSAGE)
				VALUES ('".$user_email."', '".$user_sender_email[$replyNumber]."', '".date("Y-m-d h:i:sa")."', '".$_POST['message'][$replyNumber]."');";
			$result = $conn->query($sql);
			$missing[$replyNumber] = "MESSAGE SENT SUCCESSFULLY!";
			//header('Location: Jobs.php');
		}
	} else if (isset($_POST['activity'])) {
		$temp = array_keys($_REQUEST['activity']);
	    $activityNumber = array_pop($temp);
		
		if($_POST['message'][$activityNumber] == "" || $_POST['rate'][$activityNumber] == "") {
			$missing[$activityNumber] = "PLEASE LEAVE A FEEDBACK AND RATE THE FREELANCER!";
			//header('Location: Jobs.php');
		} else if($_POST['rate'][$activityNumber] < 0 || $_POST['rate'][$activityNumber] > 5){
			$missing[$activityNumber] = "PLEASE ENTER A NUMBER BETWEEN 0-5!";
			//header('Location: Jobs.php');
		} else { 
			$user_first_status[$activityNumber] = 2; 
			$sql = "UPDATE orders SET first_status='".$user_first_status[$activityNumber]."' WHERE id='".$user_id[$activityNumber]."'";;
			$result = $conn->query($sql);
			$missing[$activityNumber] = "FREELANCER REVIEWED SUCCESSFULLY!";
			
			date_default_timezone_set("Asia/Dhaka");
			$sql = "INSERT INTO user_feedback (REVIEWER_EMAIL, SELLER_EMAIL, FEEDBACK, DATE_TIME, RATING)
			VALUES ('".$user_email."', '".$user_seller_email[$activityNumber]."', '".$_POST['message'][$activityNumber]."', '".date("Y-m-d h:i:sa")."', '".$_POST['rate'][$activityNumber]."');";
			$result = $conn->query($sql);
			
			
			$sql = "SELECT u.email, u.account_type, u.money, u.rating, u.job_count, f.seller_email, f.rating FROM `users` AS u INNER JOIN `user_feedback` AS f ON u.email = f.seller_email";		
			//$sql = "SELECT selleremail, rating FROM user_feedback";		
			$result = $conn->query($sql);
			
			if ($result->num_rows > 0) {
				// output data of each row
				$current_rating=0;
				while($row = $result->fetch_assoc()) {
					if($row["email"] == $user_seller_email[$activityNumber]) {
						$current_rating = $current_rating + $row["rating"];
						$jobs_completed = $row["job_count"];
						$user_money = $row["money"];
					}
				}
				$user_money = $user_money + $user_cost[$activityNumber];
				$jobs_completed++;
				$current_rating = round($current_rating/($jobs_completed));
				$sql = "UPDATE users SET job_count='".$jobs_completed."', rating='".$current_rating."', money='".$user_money."' WHERE email='".$user_seller_email[$activityNumber]."'";
				$result = $conn->query($sql);
			}
			
		}
		
			
	  //header('Location: Jobs.php');
	  
	} else if (isset($_POST['delete'])){
	  $deleteNumber = array_pop(array_keys($_REQUEST['delete']));
	  $sql = "DELETE FROM orders WHERE id = '".$user_id[$deleteNumber]."'";
	  $result = $conn->query($sql);
	  header('Location: Jobs.php');
	}
} else {
	if (isset($_POST['reply'])) {
		$temp = array_keys($_REQUEST['reply']);
		$replyNumber = array_pop($temp);
		if($_POST['message'][$replyNumber] == "") {
			$missing[$replyNumber] = "PLEASE ENTER SOME TEXTS TO REPLY!";
			//header('Location: Jobs.php');
		} else {
			date_default_timezone_set("Asia/Dhaka");  
			$temp = array_keys($_REQUEST['reply']);
			$replyNumber = array_pop($temp);
			$missing[$replyNumber] = "MESSAGE SENT SUCCESSFULLY!";
			$sql = "INSERT INTO message_box (SENDER_EMAIL, RECEIVER_EMAIL, DATE_TIME, MESSAGE)
				VALUES ('".$user_email."', '".$user_buyer_email[$replyNumber]."', '".date("Y-m-d h:i:sa")."', '".$_POST['message'][$replyNumber]."');";
			$result = $conn->query($sql);
			//header('Location: Jobs.php');
		}
	} else if (isset($_POST['activity'])) {	
	  $temp = array_keys($_REQUEST['activity']);
	  $activityNumber = array_pop($temp);
	  if($user_first_status[$activityNumber] == 0) {
		$user_first_status[$activityNumber] = 1; 
		$missing[$activityNumber] = "CONGRATULATIONS! YOU ARE HIRED!";
		$sql = "UPDATE orders SET first_status='".$user_first_status[$activityNumber]."' WHERE id='".$user_id[$activityNumber]."'";;
		$result = $conn->query($sql);
		
	  } else {
			$activityNumber = array_pop(array_keys($_REQUEST['activity']));
			if($_POST['message'][$activity] == "" || $_POST['rate'][$activityNumber] == "") {
				$missing[$activityNumber] = "PLEASE ENTER SOME TEXTS TO REPLY!";
				//header('Location: Jobs.php');
			} else if($_POST['rate'][$activityNumber] < 0 || $_POST['rate'][$activityNumber] > 5){
				$missing[$activityNumber] = "PLEASE ENTER A NUMBER BETWEEN 0-5!";
				//header('Location: Jobs.php');
			} else {
				
			}
	    }
	  //header('Location: Jobs.php');
	  
	} else if (isset($_POST['delete'])){
	  $temp = array_keys($_REQUEST['delete']);
	  $deleteNumber = array_pop($temp);
	  $sql = "DELETE FROM orders WHERE id = '".$user_id[$deleteNumber]."'";
	  $result = $conn->query($sql);
	  header('Location: Jobs.php');
	}
}

$conn->close();

?>	

<html lang="en-US">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>FB / Jobs</title>
		
		<link rel="stylesheet" type="text/css" href="home_design.css">
	</head>
	
	
	<body>
	
		<ul id="unordered_bar">
			<li style="margin-left:100px"><img id="image_logo" src="images/logo.png" alt="LOGO" width="120"></li>
			<!--<li style="color:white; margin-left:30px">
				<input id="search" type="text" placeholder="Find People" size="50">
				<button class="button" style="margin-left:5px" onclick="search_people()">GO</button>
			</li>-->
			<li style="color:white; margin-left:662px"> <a class="a1" href="Profile.php">HOME</a> </li>
			<li style="color:white; margin-left:30px"> <a class="a1" href="Message.php">MESSAGE</a> </li>
			<li style="color:#4d69f6; margin-left:30px">JOBS</li>
			<li style="color:white; margin-left:30px"> <a class="a1" href="Edit Profile.php">EDIT PROFILE</a> </li>
			<li style="color: white; margin-left:30px"> <a class="a1" href="Logout.php">LOG OUT</a> </li>
		</ul>
		
		<ul id="unordered_category" style="background-color: #e6e6e6">
			<li style="color:black; margin-left:109px"> <a href="Seller List 1.php">Graphics & Design</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 2.php">Writing & Translation</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 3.php">Programming & Tech</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 4.php">Advertising & Digital Marketing</a> </li>
			<li style="color:black; margin-left:96px"> <a href="Seller List 5.php">Video & Animation</a> </li>
		</ul>
		
		<div id="container">
			<!-- <img id="image" src="images/sign_in_wallpaper.jpg" alt="Wallpaper" width="100%"/> -->
			<!-- <span style="margin-top:-50px; margin-left:-80px; width:1420px; height:555px" id="about"></span> -->
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="background-color:#292929; width:1370px; margin-left:-450px; margin-top: -90px;">
					<?php
					
					if($order_counter == -1) {
						?><p style="color:white">No Jobs Available</p> <?php
					} else {
						for($i=0; $i<=$order_counter; $i++) {
							if($user_account_type == "seller") { 
								if($user_first_status[$i] == "0") {
									$job_stats = "Offer";
									$stats = "ACCEPT";
									$stats2 = "REJECT";
								} else if($user_first_status[$i] == "2") {
									$job_stats = "Done";
								} else {
									$job_stats = "Running";
									$stats = "CANCEL";
									$stats2 = "END";
								}
							?>
								<p style="color:white"><?php echo $user_buyer_email[$i]. " (" .$user_date_time[$i]. ") - - - - - - - - - - - - - Tk. " .$user_cost[$i]. " (".$job_stats.")"; ?></p>
								<p style="color:white; font-size:12px;"><?php echo $user_order_statement[$i]; ?></p>
								<input class="button" name="reply[<?php echo $i; ?>]" type="submit" value="REPLY" style="padding:0px; font-size: 12px; background-color: #4d69f6; width:80px; height:25px;">
								<?php if($user_first_status[$i] == 0) {
								?>		<input class="button" name="activity[<?php echo $i; ?>]" type="submit" value="<?php echo $stats; ?>" style="padding:0px; font-size: 12px; background-color: #4d69f6; width:80px; height:25px;">	
										<input class="button" name="delete[<?php echo $i; ?>]" type="submit" value="<?php echo $stats2; ?>" style="padding:0px; font-size: 12px; background-color: #4d69f6; width:80px; height:25px;"> <br/>
										<textarea class="user_edit" maxlength="2000" name="message[<?php echo $i; ?>]" type="textarea" placeholder="Enter your reply message here ..." style="font-size:12px; margin-top: 5px; background-color: white; width:1350px; height:60px;"></textarea>
									    <span style="color:red; font-size:12px; font-style:italic"><?php echo $missing[$i]; ?></span><br/><br/>
								<?php } else if($user_first_status[$i] == "2") {
								?>	<textarea class="user_edit" maxlength="2000" name="message[<?php echo $i; ?>]" type="textarea" placeholder="Enter your reply message here ..." style="font-size:12px; margin-top: 5px; background-color: white; width:1350px; height:60px;"></textarea>
									<span style="color:red; font-size:12px; font-style:italic"><?php echo $missing[$i]; ?></span><br/><br/>
								<?php } else {
								?>	<input class="button" name="activity[<?php echo $i; ?>]" type="submit" value="<?php echo $stats; ?>" style="padding:0px; font-size: 12px; background-color: #4d69f6; width:80px; height:25px;">	
									<textarea class="user_edit" maxlength="2000" name="message[<?php echo $i; ?>]" type="textarea" placeholder="Enter your reply message here ..." style="font-size:12px; margin-top: 5px; background-color: white; width:1350px; height:60px;"></textarea>
									<span style="color:red; font-size:12px; font-style:italic"><?php echo $missing[$i]; ?></span><br/><br/>
								<?php 
								}
								?>
								<?php 	} else {
								if($user_first_status[$i] == "0") {
									$job_stats = "Offered";
								} else if($user_first_status[$i] == "2") {
									$job_stats = "Done";
								} else {
									$job_stats = "Running";
								}
							?>
								<p style="color:white"><?php echo $user_seller_email[$i]. " (" .$user_date_time[$i]. ") - - - - - - - - - - - - - Tk. " .$user_cost[$i]. " (".$job_stats.")"; ?></p>
								<p style="color:white; font-size:12px;"><?php echo $user_order_statement[$i]; ?></p>
								<input class="button" name="reply[<?php echo $i; ?>]" type="submit" value="REPLY" style="padding:0px; font-size: 12px; background-color: #4d69f6; width:80px; height:25px;">
								<?php if($user_first_status[$i] == 1) {
								?>		<input class="button" name="activity[<?php echo $i; ?>]" type="submit" value="SUCCESSFUL" style="padding:0px; font-size: 12px; background-color: #4d69f6; width:95px; height:25px;">
										<input id="user_registration" name="rate[<?php echo $i; ?>]" type="number" placeholder="out of 5" style="width:100px;">
								<?php } 
								if ($user_first_status[$i] == 2) { ?>
									<textarea class="user_edit" maxlength="2000" name="message[<?php echo $i; ?>]" type="textarea" placeholder="Enter your reply message here ..." style="font-size:12px; margin-top: 5px; background-color: white; width:1350px; height:60px;"></textarea>
									<span style="color:red; font-size:12px; font-style:italic"><?php echo $missing[$i]; ?></span><br/><br/>
								<?php
								} else {
								?>	<input class="button" name="delete[<?php echo $i; ?>]" type="submit" value="CANCEL" style="padding:0px; font-size: 12px; background-color: #4d69f6; width:80px; height:25px;"> <br/>
									<textarea class="user_edit" maxlength="2000" name="message[<?php echo $i; ?>]" type="textarea" placeholder="Enter your reply message here ..." style="font-size:12px; margin-top: 5px; background-color: white; width:1350px; height:60px;"></textarea>
									<span style="color:red; font-size:12px; font-style:italic"><?php echo $missing[$i]; ?></span><br/><br/>
							
								<?php 
								}
								?>
						<?php
							}	
						} 
					} 
					
					?>
			</form>
			
		</div>
		
	</body>
</html>