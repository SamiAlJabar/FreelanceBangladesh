<!DOCTYPE html> 
<?php
	session_start();
	echo "WOW";
	$_SESSION['user_profile'] = "";
	$_SESSION["value_of_counter"] = 0;
	header('Location: Sign In.php');
?>