<?php
	session_start();
	$_SESSION['categor'] = "Writing & Translation";
	header('Location: Seller List.php');
?>